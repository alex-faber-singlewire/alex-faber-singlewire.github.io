/*
 * This AudioReplacement script demonstrats a technique for
 * adding Text To Speech (TTS) functionality to InformaCast. It accesses
 * a local TTS engine, and expects the response to be a G.711 ulaw wav file.
 *
 * This Script:
 *   1) Writes the Message's short text to a temporary text file
 *   2) Executes a process to output TTS.  The process:
 *     a) writes output from the request to the audio file
 *   3) Tells InformaCast that a dynamic audio file was created by setting dynamicAudioCreated = true;
 *   4) Cleans up the temporary text file
 *
 */

// CUSTOMIZE THESE - begin
var voice = "cepstral-allison";       // Optional, choose voice to use
var repeats = 1;                          // Do not repeat by default, set greater than 1 to repeat
var textToInclude = "both";               // Include short and long text ("both"), short ("short") or long ("long")
var breakTimeSecs = 3;                    // Define time between repeats in seconds, default to 3 seconds
// CUSTOMIZE THESE - end

// Initialize logging
var log = org.apache.log4j.Logger.getLogger("com.berbee.ipt.broadcastsystem.TTSScript");

// This function creates the text to read, concatenating the short and long text as necessary
buildMessageText = function( incl ){
  if( incl == "both" ){
    if( messageInfo.details == undefined ){
      // Read only short text, long text is empty
      return( messageInfo.shortText );
    } else {
      // Read both the short text (shortText) and long text (details)
      return( messageInfo.shortText + ", " + messageInfo.details );
    }
  } else if( incl == "short" ){
    return( messageInfo.shortText );
  } else if( incl == "long" ){
    return( messageInfo.details );
  } else {
    log.info( "VATTSAudioReplacement: textToInclude must be set to both, short or long (it is " + incl );
  }
}

// Repeat if necessary
log.info( "VATTSAudioReplacement: will repeat " + repeats + " times" );
var ttsText = buildMessageText( textToInclude );
for ( var i=1; i<repeats; i++ ){ 
  ttsText = ttsText + " <break time='" + breakTimeSecs + "s'/> " + buildMessageText( textToInclude );
}
log.info( "VATTSAudioReplacement: Text to read: " + ttsText );

// Output the text to read to a text file
var textFile = File.createTempFile("message", ".txt")
FileHelper.writeStringToFile(textFile, ttsText, false);

/* This pipeline should be used almost 100% of the time, it requests the TTS script to do
   TTS and return the result */
log.info( "VATTSAudioReplacement: Executing tts call" );
var cmd = new java.util.ArrayList();
cmd.add( "sh" );
cmd.add( "-c" );
cmd.add( "/usr/local/singlewire/tts/bin/tts-cmd "
         + "--voice " + voice 
         + " --outfile " + dynamicAudioFile.getCanonicalPath() 
         + " --text " + textFile.getCanonicalPath() );
log.info( "VATTSAudioReplacement: Executing " + cmd );
pb = new java.lang.ProcessBuilder( cmd );

pb.redirectErrorStream(true);
p = pb.start();
p.waitFor();
reader = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
line = "";

while(null != (line = reader.readLine())) {
  log.info("VATTSAudioReplacement: Pipeline Output: " + line);
}
dynamicAudioCreated = true;
textFile["delete"]();
log.info( "VATTSAudioReplacement: TTS call complete" );
